
<template>
  <div v-if="selectedShape?.isPart" class="part-inspector">
    <h3>Part Properties</h3>
    <div v-for="(value, key) in editableFields" :key="key" class="field-row">
      <label>{{ key }}</label>
      <input v-model="editableFields[key]" @blur="saveField(key)" />
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { usePageStore } from '@/stores/pages'
import { useBomStore } from '@/stores/bomStore'

const pageStore = usePageStore()
const bomStore = useBomStore()
const selectedShape = ref(null)
const editableFields = ref({})

watch(() => pageStore.selectedShapeId, (newId) => {
  const page = pageStore.pages.find(p => p.id === pageStore.activePageId)
  if (!page) return

  for (const layer of page.layers) {
    const shape = layer.shapes.find(s => s.id === newId)
    if (shape?.isPart) {
      selectedShape.value = shape
      editableFields.value = {
        tag: shape.tag || '',
        partNumber: shape.partNumber || '',
        config: shape.config || '',
        quantity: shape.quantity || 1,
        manufacturer: shape.manufacturer || '',
        pointType: shape.pointType || '',
        description: shape.description || '',
        productCut: shape.productCut || '',
        wireDiagram: shape.wireDiagram || ''
      }
      return
    }
  }

  selectedShape.value = null
  editableFields.value = {}
}, { immediate: true })

function saveField(field) {
  if (!selectedShape.value) return
  selectedShape.value[field] = editableFields.value[field]
  bomStore.updatePart(selectedShape.value.id, { [field]: editableFields.value[field] })
}
</script>

<style scoped>
.part-inspector {
  padding: 1rem;
  background: #1e1e1e;
  color: #eee;
  border-left: 1px solid #444;
}
.field-row {
  display: flex;
  flex-direction: column;
  margin-bottom: 0.5rem;
}
input {
  background: #2a2a2a;
  color: #fff;
  border: 1px solid #555;
  padding: 4px;
}
</style>
