
// utils/makeShapePart.js
import { usePageStore } from '@/stores/pages'
import { useBomStore } from '@/stores/bomStore'

export function makeShapePart(shapeId) {
  const pageStore = usePageStore()
  const bomStore = useBomStore()

  const page = pageStore.pages.find(p => p.id === pageStore.activePageId)
  if (!page) return

  let shape
  for (const layer of page.layers) {
    shape = layer.shapes.find(s => s.id === shapeId)
    if (shape) break
  }

  if (!shape) return

  // Inject part metadata
  const partData = {
    ...shape,
    isPart: true,
    tag: shape.tag || '',
    partNumber: shape.partNumber || '',
    config: shape.config || '',
    quantity: shape.quantity || 1,
    manufacturer: shape.manufacturer || '',
    pointType: shape.pointType || '',
    description: shape.description || '',
    autoTag: true,
    productCut: shape.productCut || '',
    wireDiagram: shape.wireDiagram || ''
  }

  // Add to BOM and update shape metadata
  bomStore.addPart(partData)

  // Optionally mutate the shape directly
  shape.isPart = true
  shape.tag = partData.tag
  shape.partNumber = partData.partNumber
  shape.description = partData.description
  shape.quantity = partData.quantity
}
