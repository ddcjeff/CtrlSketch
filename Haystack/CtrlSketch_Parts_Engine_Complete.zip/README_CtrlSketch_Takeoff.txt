
README – Takeoff Engine (ctrlsketch_blackwall_takeoff.py)
=========================================================

This file explains how to run the local BOM takeoff engine used by CtrlSketch.

──────────────────────────────────────────────
1. WHAT IT IS
──────────────────────────────────────────────

This is a Flask-based Python API that uses your real parts list
(PartList.csv) to return matching BOM components from free-form
input.

──────────────────────────────────────────────
2. USAGE
──────────────────────────────────────────────

Step 1: Make sure Python is installed

Step 2: Open a terminal in the same folder as the files

Step 3: Install requirements:
    pip install flask pandas

Step 4: Run the server:
    python ctrlsketch_blackwall_takeoff.py

Step 5: POST requests to:
    http://localhost:5050/takeoff

Example payload:
{
  "request": [
    { "category": "sensor", "mount": "duct" },
    { "category": "controller", "platform": "jace" }
  ]
}

──────────────────────────────────────────────
3. RESPONSE
──────────────────────────────────────────────

Returns:
{
  "optimized_bom": [
    {
      "part": "A/CP-SP",
      "description": "10K Type II Stainless Wall Plate Sensor",
      "manufacturer": "ACI",
      "category": "Temperature"
    }
  ]
}
