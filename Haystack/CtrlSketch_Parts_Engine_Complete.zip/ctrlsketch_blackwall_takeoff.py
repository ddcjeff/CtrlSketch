
from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)
parts_df = pd.read_csv('PartList.csv', encoding='latin1')
parts_df.columns = [
    "item_id", "part_number", "manufacturer", "brand", "category", "type",
    "price_1", "price_2", "price_3", "description", "ignore", "cut_sheet"
]

@app.route('/takeoff', methods=['POST'])
def takeoff():
    try:
        data = request.get_json()
        requests = data.get("request", [])

        results = []
        for req in requests:
            matched = None
            cat = req.get("category", "").lower()
            mount = req.get("mount", "").lower()
            platform = req.get("platform", "").lower()
            voltage = req.get("voltage", "").lower()

            for _, row in parts_df.iterrows():
                desc = str(row.get("description", "")).lower()
                type_field = str(row.get("type", "")).lower()
                category = str(row.get("category", "")).lower()

                if cat in category or cat in desc:
                    if mount and mount not in type_field and mount not in desc:
                        continue
                    if platform and platform not in type_field and platform not in desc:
                        continue
                    if voltage and voltage not in type_field and voltage not in desc:
                        continue

                    matched = {
                        "part": row.get("part_number", "UNKNOWN"),
                        "description": row.get("description", "No description"),
                        "manufacturer": row.get("manufacturer", "N/A"),
                        "category": row.get("category", "Uncategorized"),
                    }
                    break

            results.append(matched or {"part": "Not found", "reason": req})

        return jsonify({"optimized_bom": results})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050)
