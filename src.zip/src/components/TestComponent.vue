<template>
  <div class="p-6 max-w-sm mx-auto bg-white rounded-xl shadow-md flex items-center space-x-4">
    <div class="flex-shrink-0">
      <div class="h-12 w-12 bg-indigo-500 rounded-full flex items-center justify-center text-white font-bold">CS</div>
    </div>
    <div>
      <div class="text-xl font-medium text-black">CtrlSketch</div>
      <p class="text-gray-500">Ready to draw!</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TestComponent'
}
</script>